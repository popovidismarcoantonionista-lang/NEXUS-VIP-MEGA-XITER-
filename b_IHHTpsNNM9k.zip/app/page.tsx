import { CheckoutFlow } from '@/components/checkout/checkout-flow'
import { MatrixBackground } from '@/components/matrix-background'
import { Shield, Terminal, Lock, Zap } from 'lucide-react'

export default function HomePage() {
  return (
    <main className="min-h-screen relative">
      {/* Background animado */}
      <MatrixBackground />
      
      {/* Conteúdo principal */}
      <div className="relative z-10 min-h-screen flex flex-col">
        {/* Header */}
        <header className="border-b border-border/50 backdrop-blur-sm bg-background/80">
          <div className="container mx-auto px-4 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Terminal className="w-6 h-6 text-primary" />
                <span className="font-mono font-bold text-lg text-primary">NEXUS</span>
              </div>
              
              <div className="flex items-center gap-4 text-xs font-mono text-muted-foreground">
                <span className="hidden sm:flex items-center gap-1">
                  <div className="w-2 h-2 rounded-full bg-primary animate-pulse" />
                  SISTEMA ONLINE
                </span>
                <span className="flex items-center gap-1">
                  <Shield className="w-4 h-4" />
                  SEGURO
                </span>
              </div>
            </div>
          </div>
        </header>

        {/* Hero Section */}
        <section className="py-8 md:py-12 border-b border-border/30">
          <div className="container mx-auto px-4 text-center">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-primary/10 rounded-full border border-primary/30 mb-4">
              <Zap className="w-4 h-4 text-primary" />
              <span className="text-xs font-mono text-primary">PREÇOS DE LANÇAMENTO</span>
            </div>
            
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold font-mono mb-4">
              <span className="text-foreground">ADQUIRA SUA</span>
              <br />
              <span className="text-primary neon-glow">NEXUS KEY</span>
            </h1>
            
            <p className="text-muted-foreground font-mono text-sm md:text-base max-w-md mx-auto">
              Acesso premium com proteção exclusiva.
              Pagamento instantâneo via PIX.
            </p>
          </div>
        </section>

        {/* Checkout Section */}
        <section className="flex-1 py-8 md:py-12">
          <div className="container mx-auto px-4">
            <CheckoutFlow />
          </div>
        </section>

        {/* Features Footer */}
        <section className="border-t border-border/30 py-8 backdrop-blur-sm bg-background/50">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="w-12 h-12 mx-auto mb-3 rounded-lg bg-primary/10 border border-primary/30 flex items-center justify-center">
                  <Lock className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-mono text-sm font-bold text-foreground mb-1">Anti-Share</h3>
                <p className="text-xs text-muted-foreground font-mono">1 Key = 1 Dispositivo</p>
              </div>
              
              <div className="text-center">
                <div className="w-12 h-12 mx-auto mb-3 rounded-lg bg-primary/10 border border-primary/30 flex items-center justify-center">
                  <Shield className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-mono text-sm font-bold text-foreground mb-1">Proteção Total</h3>
                <p className="text-xs text-muted-foreground font-mono">Sistema blindado</p>
              </div>
              
              <div className="text-center">
                <div className="w-12 h-12 mx-auto mb-3 rounded-lg bg-primary/10 border border-primary/30 flex items-center justify-center">
                  <Zap className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-mono text-sm font-bold text-foreground mb-1">PIX Instantâneo</h3>
                <p className="text-xs text-muted-foreground font-mono">Ativação automática</p>
              </div>
              
              <div className="text-center">
                <div className="w-12 h-12 mx-auto mb-3 rounded-lg bg-primary/10 border border-primary/30 flex items-center justify-center">
                  <Terminal className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-mono text-sm font-bold text-foreground mb-1">Suporte 24h</h3>
                <p className="text-xs text-muted-foreground font-mono">Sempre disponível</p>
              </div>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="border-t border-border/30 py-4 backdrop-blur-sm bg-background/80">
          <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-xs font-mono text-muted-foreground">
              <div className="flex items-center gap-2">
                <Terminal className="w-4 h-4 text-primary" />
                <span>NEXUS KEY SYSTEM v1.0</span>
              </div>
              <div className="flex items-center gap-4">
                <span>Pagamento 100% seguro</span>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </main>
  )
}
