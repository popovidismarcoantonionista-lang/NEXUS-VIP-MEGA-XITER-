'use client'

import { useState, useEffect } from 'react'
import { Shield, Loader2, CheckCircle2, XCircle, AlertTriangle } from 'lucide-react'

declare global {
  interface Window {
    Android?: {
      sucesso: (key: string, token: string, expiraEm: string) => void
      erro: (mensagem: string, codigo: string) => void
      getDeviceId: () => string
    }
  }
}

type ValidationStatus = 'idle' | 'validating' | 'success' | 'error'

interface ValidationResult {
  status: 'valida' | 'expirada' | 'invalida' | 'bloqueada' | 'suspensa'
  token?: string
  expiraEm?: string
  mensagem?: string
}

export default function ValidarPage() {
  const [key, setKey] = useState('')
  const [status, setStatus] = useState<ValidationStatus>('idle')
  const [result, setResult] = useState<ValidationResult | null>(null)
  const [deviceId, setDeviceId] = useState<string>('')

  useEffect(() => {
    // Tenta obter deviceId do Android
    if (typeof window !== 'undefined' && window.Android?.getDeviceId) {
      try {
        const id = window.Android.getDeviceId()
        setDeviceId(id)
      } catch {
        // Gera deviceId local se nao conseguir do Android
        const localId = localStorage.getItem('nx_device_id') || generateDeviceId()
        localStorage.setItem('nx_device_id', localId)
        setDeviceId(localId)
      }
    } else {
      // Ambiente web normal
      const localId = localStorage.getItem('nx_device_id') || generateDeviceId()
      localStorage.setItem('nx_device_id', localId)
      setDeviceId(localId)
    }
  }, [])

  function generateDeviceId(): string {
    const array = new Uint8Array(16)
    crypto.getRandomValues(array)
    return Array.from(array, b => b.toString(16).padStart(2, '0')).join('')
  }

  async function validarKey() {
    if (!key.trim()) return
    
    setStatus('validating')
    setResult(null)

    try {
      const response = await fetch('/api/validate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          key: key.trim().toUpperCase(),
          deviceId,
          ip: '' // IP sera detectado no backend
        })
      })

      const data = await response.json()

      if (response.ok && data.status === 'valida') {
        setStatus('success')
        setResult({
          status: 'valida',
          token: data.token,
          expiraEm: data.expiraEm
        })

        // Comunica sucesso ao Android
        if (window.Android?.sucesso) {
          window.Android.sucesso(key, data.token, data.expiraEm || '')
        }
      } else {
        setStatus('error')
        setResult({
          status: data.status || 'invalida',
          mensagem: data.error || 'Key invalida'
        })

        // Comunica erro ao Android
        if (window.Android?.erro) {
          window.Android.erro(data.error || 'Key invalida', data.status || 'invalida')
        }
      }
    } catch {
      setStatus('error')
      setResult({
        status: 'invalida',
        mensagem: 'Erro de conexao'
      })

      if (window.Android?.erro) {
        window.Android.erro('Erro de conexao', 'network_error')
      }
    }
  }

  function getStatusMessage() {
    if (!result) return null

    switch (result.status) {
      case 'valida':
        return 'Key validada com sucesso!'
      case 'expirada':
        return 'Esta key expirou'
      case 'bloqueada':
        return 'Key bloqueada - dispositivo diferente'
      case 'suspensa':
        return 'Key suspensa por atividade suspeita'
      default:
        return result.mensagem || 'Key invalida'
    }
  }

  function getStatusIcon() {
    switch (status) {
      case 'validating':
        return <Loader2 className="w-16 h-16 text-primary animate-spin" />
      case 'success':
        return <CheckCircle2 className="w-16 h-16 text-green-500" />
      case 'error':
        return result?.status === 'bloqueada' || result?.status === 'suspensa'
          ? <AlertTriangle className="w-16 h-16 text-yellow-500" />
          : <XCircle className="w-16 h-16 text-red-500" />
      default:
        return <Shield className="w-16 h-16 text-primary" />
    }
  }

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-sm">
        <div className="bg-card border border-border rounded-xl p-6 shadow-2xl">
          {/* Header */}
          <div className="text-center mb-6">
            <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-primary/10 border border-primary/30 flex items-center justify-center">
              {getStatusIcon()}
            </div>
            <h1 className="text-xl font-mono font-bold text-foreground">
              {status === 'idle' && 'VALIDAR KEY'}
              {status === 'validating' && 'VALIDANDO...'}
              {status === 'success' && 'SUCESSO'}
              {status === 'error' && 'ERRO'}
            </h1>
            {status !== 'idle' && (
              <p className="text-sm text-muted-foreground font-mono mt-2">
                {getStatusMessage()}
              </p>
            )}
          </div>

          {/* Form */}
          {(status === 'idle' || status === 'error') && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-mono text-muted-foreground mb-2 uppercase">
                  Sua Key
                </label>
                <input
                  type="text"
                  value={key}
                  onChange={(e) => setKey(e.target.value.toUpperCase())}
                  placeholder="NX-XXXX-XXXX"
                  className="w-full px-4 py-3 bg-muted border border-border rounded-lg font-mono text-center text-lg tracking-wider focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent uppercase"
                  maxLength={12}
                />
              </div>

              <button
                onClick={validarKey}
                disabled={!key.trim() || status === 'validating'}
                className="w-full py-3 bg-primary text-primary-foreground font-mono font-bold rounded-lg hover:bg-primary/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                VALIDAR
              </button>
            </div>
          )}

          {/* Success Info */}
          {status === 'success' && result?.token && (
            <div className="space-y-4">
              <div className="p-3 bg-green-500/10 border border-green-500/30 rounded-lg">
                <p className="text-xs font-mono text-green-400 text-center">
                  Token de sessao gerado
                </p>
              </div>
              
              {result.expiraEm && (
                <div className="text-center">
                  <p className="text-xs text-muted-foreground font-mono">
                    Expira em: {new Date(result.expiraEm).toLocaleDateString('pt-BR')}
                  </p>
                </div>
              )}

              <button
                onClick={() => {
                  setStatus('idle')
                  setKey('')
                  setResult(null)
                }}
                className="w-full py-2 bg-muted text-foreground font-mono text-sm rounded-lg hover:bg-muted/80 transition-colors"
              >
                VALIDAR OUTRA
              </button>
            </div>
          )}

          {/* Device ID (hidden in production) */}
          <div className="mt-6 pt-4 border-t border-border">
            <p className="text-[10px] text-muted-foreground/50 font-mono text-center break-all">
              ID: {deviceId.slice(0, 8)}...
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
