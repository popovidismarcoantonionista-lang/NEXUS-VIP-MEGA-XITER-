import { NextRequest, NextResponse } from 'next/server'
import { MercadoPagoConfig, Payment } from 'mercadopago'
import { buscarKeyPorPayment, atualizarStatusPagamento } from '@/lib/keys'
import { registrarLog, validarWebhookMercadoPago } from '@/lib/security'
import { createAdminClient } from '@/lib/supabase/admin'

const client = new MercadoPagoConfig({
  accessToken: process.env.MERCADOPAGO_ACCESS_TOKEN!
})

export async function POST(request: NextRequest) {
  try {
    const ip = request.headers.get('x-forwarded-for')?.split(',')[0] || 'unknown'
    
    // Headers de segurança do Mercado Pago
    const xSignature = request.headers.get('x-signature')
    const xRequestId = request.headers.get('x-request-id')
    
    const body = await request.json()
    
    // Log do webhook recebido
    await registrarLog('WEBHOOK_RECEBIDO', {
      ip,
      detalhes: { type: body.type, action: body.action, dataId: body.data?.id }
    })

    // Valida assinatura do webhook (se secret configurado)
    const webhookSecret = process.env.MERCADOPAGO_WEBHOOK_SECRET
    if (webhookSecret && body.data?.id) {
      const isValid = validarWebhookMercadoPago(
        xSignature,
        xRequestId,
        String(body.data.id),
        webhookSecret
      )
      
      if (!isValid) {
        await registrarLog('WEBHOOK_ASSINATURA_INVALIDA', {
          ip,
          detalhes: { xSignature, xRequestId, dataId: body.data.id }
        })
        return NextResponse.json({ error: 'Assinatura inválida' }, { status: 401 })
      }
    }

    // Processa apenas notificações de pagamento
    if (body.type !== 'payment') {
      return NextResponse.json({ received: true })
    }

    const paymentId = String(body.data.id)
    
    // Busca dados do pagamento no Mercado Pago
    const payment = new Payment(client)
    const paymentData = await payment.get({ id: paymentId })

    if (!paymentData) {
      return NextResponse.json({ error: 'Pagamento não encontrado' }, { status: 404 })
    }

    // Busca key associada
    const key = await buscarKeyPorPayment(paymentId)
    
    if (!key) {
      await registrarLog('WEBHOOK_KEY_NAO_ENCONTRADA', {
        ip,
        detalhes: { paymentId }
      })
      return NextResponse.json({ error: 'Key não encontrada' }, { status: 404 })
    }

    // Mapeia status do Mercado Pago
    let status: 'pending' | 'approved' | 'rejected' | 'cancelled'
    switch (paymentData.status) {
      case 'approved':
        status = 'approved'
        break
      case 'rejected':
        status = 'rejected'
        break
      case 'cancelled':
        status = 'cancelled'
        break
      default:
        status = 'pending'
    }

    // Atualiza status da key
    await atualizarStatusPagamento(key.id, status)

    // Atualiza tabela de payments
    const supabase = createAdminClient()
    await supabase
      .from('payments')
      .update({
        status,
        atualizado_em: new Date().toISOString(),
        webhook_data: body
      })
      .eq('payment_id', paymentId)

    // Log
    await registrarLog('WEBHOOK_PROCESSADO', {
      keyId: key.id,
      ip,
      detalhes: { paymentId, status, mpStatus: paymentData.status }
    })

    return NextResponse.json({ success: true, status })

  } catch (error) {
    console.error('Erro no webhook:', error)
    await registrarLog('WEBHOOK_ERRO', {
      detalhes: { error: String(error) }
    })
    return NextResponse.json(
      { error: 'Erro interno' },
      { status: 500 }
    )
  }
}

// Mercado Pago pode fazer GET para verificar endpoint
export async function GET() {
  return NextResponse.json({ status: 'ok' })
}
