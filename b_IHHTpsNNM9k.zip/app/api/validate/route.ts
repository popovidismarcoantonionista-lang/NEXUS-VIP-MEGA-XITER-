import { NextRequest, NextResponse } from 'next/server'
import {
  buscarKey,
  keyExpirada,
  vincularDevice,
  atualizarUltimoUso,
  incrementarTentativasBloqueadas,
  suspenderKey,
  ipSuspeito
} from '@/lib/keys'
import { gerarToken, registrarLog, checkRateLimit } from '@/lib/security'
import type { ValidationResult } from '@/lib/types'

const MAX_TENTATIVAS_BLOQUEIO = 5
const MAX_IP_SUSPEITOS = 3

export async function POST(request: NextRequest) {
  try {
    const ip = request.headers.get('x-forwarded-for')?.split(',')[0] || 'unknown'
    const userAgent = request.headers.get('user-agent') || 'unknown'
    
    // Rate limiting por IP
    if (!checkRateLimit(`validate:${ip}`, 20, 60000)) {
      await registrarLog('RATE_LIMIT_VALIDACAO', { ip, userAgent })
      return NextResponse.json(
        { status: 'blocked', message: 'Muitas tentativas. Aguarde.' } as ValidationResult,
        { status: 429 }
      )
    }

    const body = await request.json()
    const { key: keyText, deviceId } = body

    // Valida input
    if (!keyText || !deviceId) {
      return NextResponse.json(
        { status: 'invalid', message: 'Key e deviceId são obrigatórios' } as ValidationResult,
        { status: 400 }
      )
    }

    // Valida formato da key
    const keyRegex = /^NX-[A-Z0-9]{4}-[A-Z0-9]{4}$/
    if (!keyRegex.test(keyText.toUpperCase())) {
      await registrarLog('KEY_FORMATO_INVALIDO', {
        keyText,
        deviceId,
        ip,
        userAgent
      })
      return NextResponse.json(
        { status: 'invalid', message: 'Formato de key inválido' } as ValidationResult,
        { status: 400 }
      )
    }

    // Busca key no banco
    const key = await buscarKey(keyText)

    if (!key) {
      await registrarLog('KEY_NAO_ENCONTRADA', {
        keyText,
        deviceId,
        ip,
        userAgent
      })
      return NextResponse.json(
        { status: 'invalid', message: 'Key não encontrada' } as ValidationResult,
        { status: 404 }
      )
    }

    // Verifica se pagamento foi aprovado
    if (key.payment_status !== 'approved') {
      await registrarLog('KEY_PAGAMENTO_PENDENTE', {
        keyId: key.id,
        keyText,
        deviceId,
        ip,
        userAgent,
        detalhes: { paymentStatus: key.payment_status }
      })
      return NextResponse.json(
        { status: 'invalid', message: 'Pagamento não confirmado' } as ValidationResult,
        { status: 403 }
      )
    }

    // Verifica se key está suspensa
    if (key.suspensa) {
      await registrarLog('KEY_SUSPENSA_TENTATIVA', {
        keyId: key.id,
        keyText,
        deviceId,
        ip,
        userAgent,
        detalhes: { motivo: key.motivo_suspensao }
      })
      return NextResponse.json(
        { status: 'suspended', message: 'Key suspensa por atividade suspeita' } as ValidationResult,
        { status: 403 }
      )
    }

    // Verifica se key está ativa
    if (!key.ativa) {
      await registrarLog('KEY_INATIVA', {
        keyId: key.id,
        keyText,
        deviceId,
        ip,
        userAgent
      })
      return NextResponse.json(
        { status: 'invalid', message: 'Key desativada' } as ValidationResult,
        { status: 403 }
      )
    }

    // Verifica expiração
    if (keyExpirada(key)) {
      await registrarLog('KEY_EXPIRADA', {
        keyId: key.id,
        keyText,
        deviceId,
        ip,
        userAgent,
        detalhes: { expiraEm: key.expira_em }
      })
      return NextResponse.json(
        { status: 'expired', message: 'Key expirada' } as ValidationResult,
        { status: 403 }
      )
    }

    // PRIMEIRA ATIVAÇÃO - Vincula dispositivo
    if (!key.device_id) {
      await vincularDevice(key.id, deviceId, ip)
      
      await registrarLog('KEY_VINCULADA', {
        keyId: key.id,
        keyText,
        deviceId,
        ip,
        userAgent
      })
      
      // Gera token
      const token = await gerarToken(key.id, deviceId)
      const expiresAt = new Date(Date.now() + 10 * 60 * 1000).toISOString()
      
      return NextResponse.json({
        status: 'valid',
        token,
        expiresAt
      } as ValidationResult)
    }

    // VERIFICAÇÃO DE DISPOSITIVO
    if (key.device_id !== deviceId) {
      // Dispositivo diferente - BLOQUEAR
      const tentativas = await incrementarTentativasBloqueadas(key.id)
      
      await registrarLog('DEVICE_DIFERENTE', {
        keyId: key.id,
        keyText,
        deviceId,
        ip,
        userAgent,
        detalhes: {
          deviceOriginal: key.device_id,
          tentativas
        }
      })

      // Suspende se muitas tentativas
      if (tentativas >= MAX_TENTATIVAS_BLOQUEIO) {
        await suspenderKey(key.id, 'Múltiplas tentativas de uso em dispositivos diferentes')
        
        await registrarLog('KEY_SUSPENSA_AUTO', {
          keyId: key.id,
          keyText,
          deviceId,
          ip,
          userAgent,
          detalhes: { motivo: 'Excedeu limite de tentativas' }
        })
      }

      return NextResponse.json(
        { status: 'blocked', message: 'Esta key já está vinculada a outro dispositivo' } as ValidationResult,
        { status: 403 }
      )
    }

    // VERIFICAÇÃO DE IP SUSPEITO
    if (ipSuspeito(key.ip, ip)) {
      await registrarLog('IP_SUSPEITO', {
        keyId: key.id,
        keyText,
        deviceId,
        ip,
        userAgent,
        detalhes: { ipOriginal: key.ip }
      })
      
      // Não bloqueia, mas registra
      // Em casos extremos pode suspender
    }

    // TUDO OK - Atualiza último uso e gera token
    await atualizarUltimoUso(key.id, ip)
    
    const token = await gerarToken(key.id, deviceId)
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000).toISOString()

    await registrarLog('VALIDACAO_OK', {
      keyId: key.id,
      keyText,
      deviceId,
      ip,
      userAgent
    })

    return NextResponse.json({
      status: 'valid',
      token,
      expiresAt
    } as ValidationResult)

  } catch (error) {
    console.error('Erro na validação:', error)
    return NextResponse.json(
      { status: 'invalid', message: 'Erro interno' } as ValidationResult,
      { status: 500 }
    )
  }
}
