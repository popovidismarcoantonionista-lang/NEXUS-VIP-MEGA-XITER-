import { NextRequest, NextResponse } from 'next/server'
import { MercadoPagoConfig, Payment } from 'mercadopago'
import { criarKey } from '@/lib/keys'
import { registrarLog, checkRateLimit } from '@/lib/security'
import { createAdminClient } from '@/lib/supabase/admin'
import { PLANOS } from '@/lib/types'

const client = new MercadoPagoConfig({
  accessToken: process.env.MERCADOPAGO_ACCESS_TOKEN!
})

export async function POST(request: NextRequest) {
  try {
    const ip = request.headers.get('x-forwarded-for')?.split(',')[0] || 'unknown'
    
    // Rate limiting
    if (!checkRateLimit(`pix:${ip}`, 5, 60000)) {
      await registrarLog('RATE_LIMIT_PIX', { ip })
      return NextResponse.json(
        { success: false, error: 'Muitas requisições. Aguarde um momento.' },
        { status: 429 }
      )
    }

    const body = await request.json()
    const { planoId, email } = body

    // Valida plano
    const plano = PLANOS.find(p => p.id === planoId)
    if (!plano) {
      return NextResponse.json(
        { success: false, error: 'Plano inválido' },
        { status: 400 }
      )
    }

    // Valida email (opcional mas recomendado)
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (email && !emailRegex.test(email)) {
      return NextResponse.json(
        { success: false, error: 'Email inválido' },
        { status: 400 }
      )
    }

    // Cria pagamento PIX no Mercado Pago
    const payment = new Payment(client)
    
    // Monta corpo do pagamento
    const paymentBody: {
      transaction_amount: number
      description: string
      payment_method_id: string
      payer: { email: string }
      notification_url?: string
    } = {
      transaction_amount: plano.preco / 100, // Converte centavos para reais
      description: `NEXUS KEY - ${plano.nome}`,
      payment_method_id: 'pix',
      payer: {
        email: email || 'cliente@nexuskey.com'
      }
    }

    // Adiciona webhook apenas se tiver URL publica configurada
    const appUrl = process.env.NEXT_PUBLIC_APP_URL
    if (appUrl && !appUrl.includes('localhost') && !appUrl.includes('127.0.0.1')) {
      paymentBody.notification_url = `${appUrl}/api/webhook/mercadopago`
    }
    
    const paymentData = await payment.create({
      body: paymentBody
    })

    if (!paymentData.id) {
      throw new Error('Falha ao criar pagamento')
    }

    // Cria key no banco com status pending
    const key = await criarKey(
      plano.id,
      plano.preco,
      String(paymentData.id),
      email
    )

    if (!key) {
      throw new Error('Falha ao criar key')
    }

    // Salva dados do pagamento
    const supabase = createAdminClient()
    await supabase.from('payments').insert({
      payment_id: String(paymentData.id),
      key_id: key.id,
      status: 'pending',
      plano: plano.id,
      valor_centavos: plano.preco,
      email: email || null,
      qr_code: paymentData.point_of_interaction?.transaction_data?.qr_code || null,
      qr_code_base64: paymentData.point_of_interaction?.transaction_data?.qr_code_base64 || null,
      pix_copia_cola: paymentData.point_of_interaction?.transaction_data?.qr_code || null
    })

    // Log
    await registrarLog('PAGAMENTO_CRIADO', {
      keyId: key.id,
      ip,
      detalhes: { plano: plano.id, paymentId: paymentData.id }
    })

    return NextResponse.json({
      success: true,
      paymentId: String(paymentData.id),
      qrCode: paymentData.point_of_interaction?.transaction_data?.qr_code || null,
      qrCodeBase64: paymentData.point_of_interaction?.transaction_data?.qr_code_base64 || null,
      pixCopiaCola: paymentData.point_of_interaction?.transaction_data?.qr_code || null
    })

  } catch (error) {
    console.error('Erro ao criar PIX:', error)
    return NextResponse.json(
      { success: false, error: 'Erro interno ao processar pagamento' },
      { status: 500 }
    )
  }
}
