import { NextRequest, NextResponse } from 'next/server'
import { MercadoPagoConfig, Payment } from 'mercadopago'
import { buscarKeyPorPayment, atualizarStatusPagamento } from '@/lib/keys'
import { registrarLog } from '@/lib/security'
import { createAdminClient } from '@/lib/supabase/admin'

const client = new MercadoPagoConfig({
  accessToken: process.env.MERCADOPAGO_ACCESS_TOKEN!
})

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const paymentId = searchParams.get('paymentId')

    if (!paymentId) {
      return NextResponse.json(
        { success: false, error: 'paymentId é obrigatório' },
        { status: 400 }
      )
    }

    // Busca status do pagamento no Mercado Pago
    const payment = new Payment(client)
    const paymentData = await payment.get({ id: paymentId })

    // Busca key associada
    const key = await buscarKeyPorPayment(paymentId)

    if (!key) {
      return NextResponse.json({
        success: false,
        error: 'Key não encontrada'
      }, { status: 404 })
    }

    // Se pagamento aprovado no MP mas key ainda pendente, atualiza a key
    if (paymentData.status === 'approved' && key.payment_status !== 'approved') {
      // Atualiza status da key para approved
      await atualizarStatusPagamento(key.id, 'approved')

      // Atualiza tabela de payments
      const supabase = createAdminClient()
      await supabase
        .from('payments')
        .update({
          status: 'approved',
          atualizado_em: new Date().toISOString()
        })
        .eq('payment_id', paymentId)

      // Log
      await registrarLog('PAGAMENTO_APROVADO_POLLING', {
        keyId: key.id,
        detalhes: { paymentId, mpStatus: paymentData.status }
      })

      // Retorna key
      return NextResponse.json({
        success: true,
        status: 'approved',
        key: key.key,
        plano: key.plano
      })
    }

    // Se pagamento rejeitado ou cancelado
    if (paymentData.status === 'rejected' || paymentData.status === 'cancelled') {
      if (key.payment_status === 'pending') {
        const newStatus = paymentData.status as 'rejected' | 'cancelled'
        await atualizarStatusPagamento(key.id, newStatus)
        
        const supabase = createAdminClient()
        await supabase
          .from('payments')
          .update({
            status: newStatus,
            atualizado_em: new Date().toISOString()
          })
          .eq('payment_id', paymentId)
      }

      return NextResponse.json({
        success: true,
        status: paymentData.status,
        key: null,
        plano: key.plano
      })
    }

    // Retorna status atual
    return NextResponse.json({
      success: true,
      status: paymentData.status,
      key: key.payment_status === 'approved' ? key.key : null,
      plano: key.plano
    })

  } catch (error) {
    console.error('Erro ao verificar status:', error)
    return NextResponse.json(
      { success: false, error: 'Erro ao verificar status do pagamento' },
      { status: 500 }
    )
  }
}
