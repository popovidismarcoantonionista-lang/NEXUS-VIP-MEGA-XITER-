import { NextRequest, NextResponse } from 'next/server'
import { verificarToken, gerarToken, registrarLog, checkRateLimit } from '@/lib/security'
import { buscarKey, keyExpirada, atualizarUltimoUso } from '@/lib/keys'

export async function POST(request: NextRequest) {
  try {
    const ip = request.headers.get('x-forwarded-for')?.split(',')[0] || 'unknown'
    const userAgent = request.headers.get('user-agent') || 'unknown'
    
    // Rate limiting
    if (!checkRateLimit(`refresh:${ip}`, 30, 60000)) {
      return NextResponse.json(
        { success: false, error: 'Muitas requisições' },
        { status: 429 }
      )
    }

    const body = await request.json()
    const { token } = body

    if (!token) {
      return NextResponse.json(
        { success: false, error: 'Token é obrigatório' },
        { status: 400 }
      )
    }

    // Verifica token atual
    const tokenData = await verificarToken(token)
    
    if (!tokenData) {
      await registrarLog('TOKEN_INVALIDO', {
        ip,
        userAgent,
        detalhes: { tokenPrefix: token.substring(0, 20) }
      })
      return NextResponse.json(
        { success: false, error: 'Token inválido ou expirado' },
        { status: 401 }
      )
    }

    // Busca key para verificar se ainda está válida
    const { keyId, deviceId } = tokenData
    
    // Busca por ID (precisamos adicionar função)
    const { createAdminClient } = await import('@/lib/supabase/admin')
    const supabase = createAdminClient()
    
    const { data: key, error } = await supabase
      .from('keys')
      .select('*')
      .eq('id', keyId)
      .single()

    if (error || !key) {
      return NextResponse.json(
        { success: false, error: 'Key não encontrada' },
        { status: 404 }
      )
    }

    // Verifica se key ainda está ativa
    if (!key.ativa || key.suspensa) {
      return NextResponse.json(
        { success: false, error: 'Key não está mais ativa' },
        { status: 403 }
      )
    }

    // Verifica expiração
    if (keyExpirada(key)) {
      return NextResponse.json(
        { success: false, error: 'Key expirada' },
        { status: 403 }
      )
    }

    // Verifica device
    if (key.device_id !== deviceId) {
      await registrarLog('REFRESH_DEVICE_MISMATCH', {
        keyId,
        deviceId,
        ip,
        userAgent,
        detalhes: { deviceOriginal: key.device_id }
      })
      return NextResponse.json(
        { success: false, error: 'Dispositivo não autorizado' },
        { status: 403 }
      )
    }

    // Atualiza último uso
    await atualizarUltimoUso(keyId, ip)

    // Gera novo token
    const newToken = await gerarToken(keyId, deviceId)
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000).toISOString()

    return NextResponse.json({
      success: true,
      token: newToken,
      expiresAt
    })

  } catch (error) {
    console.error('Erro no refresh:', error)
    return NextResponse.json(
      { success: false, error: 'Erro interno' },
      { status: 500 }
    )
  }
}
