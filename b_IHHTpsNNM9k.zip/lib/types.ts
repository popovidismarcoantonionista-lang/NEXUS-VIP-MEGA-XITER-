export type Plano = '1d' | '3d' | '7d' | '30d' | 'lifetime'

export interface PlanoConfig {
  id: Plano
  nome: string
  preco: number
  precoOriginal: number
  duracao: string
  diasExpiracao: number | null // null = lifetime
}

export const PLANOS: PlanoConfig[] = [
  { id: '1d', nome: 'Key 1 Dia', preco: 200, precoOriginal: 600, duracao: '24 horas', diasExpiracao: 1 },
  { id: '3d', nome: 'Key 3 Dias', preco: 1000, precoOriginal: 1500, duracao: '3 dias', diasExpiracao: 3 },
  { id: '7d', nome: 'Key 7 Dias', preco: 3000, precoOriginal: 3500, duracao: '7 dias', diasExpiracao: 7 },
  { id: '30d', nome: 'Key 30 Dias', preco: 5500, precoOriginal: 7000, duracao: '30 dias', diasExpiracao: 30 },
  { id: 'lifetime', nome: 'Key Lifetime', preco: 12000, precoOriginal: 14000, duracao: 'Vitalício', diasExpiracao: null },
]

export interface Key {
  id: string
  key: string
  plano: Plano
  preco_centavos: number
  criada_em: string
  expira_em: string | null
  ativa: boolean
  device_id: string | null
  ip: string | null
  last_use: string | null
  payment_id: string | null
  payment_status: 'pending' | 'approved' | 'rejected' | 'cancelled'
  email_comprador: string | null
  tentativas_bloqueadas: number
  suspensa: boolean
  motivo_suspensao: string | null
}

export interface SecurityLog {
  id: string
  key_id: string | null
  key_text: string | null
  evento: string
  device_id: string | null
  ip: string | null
  user_agent: string | null
  detalhes: Record<string, unknown> | null
  criado_em: string
}

export interface Payment {
  id: string
  payment_id: string
  key_id: string | null
  status: string
  plano: Plano
  valor_centavos: number
  email: string | null
  qr_code: string | null
  qr_code_base64: string | null
  pix_copia_cola: string | null
  criado_em: string
  atualizado_em: string
  webhook_data: Record<string, unknown> | null
}

export type ValidationResult = 
  | { status: 'valid'; token: string; expiresAt: string }
  | { status: 'expired'; message: string }
  | { status: 'invalid'; message: string }
  | { status: 'blocked'; message: string }
  | { status: 'suspended'; message: string }

export interface CreatePixResponse {
  success: boolean
  paymentId?: string
  qrCode?: string
  qrCodeBase64?: string
  pixCopiaCola?: string
  error?: string
}

export interface WebhookPayload {
  action: string
  api_version: string
  data: {
    id: string
  }
  date_created: string
  id: number
  live_mode: boolean
  type: string
  user_id: string
}
