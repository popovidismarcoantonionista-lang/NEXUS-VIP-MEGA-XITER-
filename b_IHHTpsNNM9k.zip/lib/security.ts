import { createAdminClient } from './supabase/admin'
import { SignJWT, jwtVerify } from 'jose'

const JWT_SECRET = new TextEncoder().encode(
  process.env.JWT_SECRET || 'nexus-key-system-secret-2024'
)

// Gera token JWT temporário (10 minutos)
export async function gerarToken(keyId: string, deviceId: string): Promise<string> {
  const token = await new SignJWT({ keyId, deviceId })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime('10m')
    .sign(JWT_SECRET)
  
  return token
}

// Verifica token JWT
export async function verificarToken(token: string): Promise<{ keyId: string; deviceId: string } | null> {
  try {
    const { payload } = await jwtVerify(token, JWT_SECRET)
    return {
      keyId: payload.keyId as string,
      deviceId: payload.deviceId as string
    }
  } catch {
    return null
  }
}

// Registra log de segurança
export async function registrarLog(
  evento: string,
  dados: {
    keyId?: string
    keyText?: string
    deviceId?: string
    ip?: string
    userAgent?: string
    detalhes?: Record<string, unknown>
  }
): Promise<void> {
  const supabase = createAdminClient()
  
  await supabase.from('security_logs').insert({
    key_id: dados.keyId || null,
    key_text: dados.keyText || null,
    evento,
    device_id: dados.deviceId || null,
    ip: dados.ip || null,
    user_agent: dados.userAgent || null,
    detalhes: dados.detalhes || null
  })
}

// Rate limiting simples em memória (em produção usar Redis)
const rateLimitMap = new Map<string, { count: number; resetAt: number }>()

export function checkRateLimit(identifier: string, maxRequests: number = 10, windowMs: number = 60000): boolean {
  const now = Date.now()
  const record = rateLimitMap.get(identifier)
  
  if (!record || now > record.resetAt) {
    rateLimitMap.set(identifier, { count: 1, resetAt: now + windowMs })
    return true
  }
  
  if (record.count >= maxRequests) {
    return false
  }
  
  record.count++
  return true
}

// Limpa rate limit map periodicamente
setInterval(() => {
  const now = Date.now()
  for (const [key, value] of rateLimitMap.entries()) {
    if (now > value.resetAt) {
      rateLimitMap.delete(key)
    }
  }
}, 60000)

// Valida assinatura do webhook Mercado Pago
export function validarWebhookMercadoPago(
  xSignature: string | null,
  xRequestId: string | null,
  dataId: string,
  secret: string
): boolean {
  if (!xSignature || !xRequestId) return false
  
  // Extrai ts e hash do header
  const parts = xSignature.split(',')
  let ts = ''
  let hash = ''
  
  for (const part of parts) {
    const [key, value] = part.split('=')
    if (key === 'ts') ts = value
    if (key === 'v1') hash = value
  }
  
  if (!ts || !hash) return false
  
  // Monta o manifest para validação
  const manifest = `id:${dataId};request-id:${xRequestId};ts:${ts};`
  
  // Calcula HMAC-SHA256
  const crypto = require('crypto')
  const expectedHash = crypto
    .createHmac('sha256', secret)
    .update(manifest)
    .digest('hex')
  
  return hash === expectedHash
}
