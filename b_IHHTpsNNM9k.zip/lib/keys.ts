import { randomBytes } from 'crypto'
import { createAdminClient } from './supabase/admin'
import type { Plano, PLANOS, Key } from './types'

// Gera key no formato NX-XXXX-XXXX
export function generateKey(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
  const segment1 = Array.from(randomBytes(4)).map(b => chars[b % chars.length]).join('')
  const segment2 = Array.from(randomBytes(4)).map(b => chars[b % chars.length]).join('')
  return `NX-${segment1}-${segment2}`
}

// Calcula data de expiração baseado no plano
export function calcularExpiracao(plano: Plano, planos: typeof PLANOS): Date | null {
  const config = planos.find(p => p.id === plano)
  if (!config || config.diasExpiracao === null) return null
  
  const expiraEm = new Date()
  expiraEm.setDate(expiraEm.getDate() + config.diasExpiracao)
  return expiraEm
}

// Cria uma nova key no banco
export async function criarKey(
  plano: Plano,
  precoCentavos: number,
  paymentId: string,
  email?: string
): Promise<Key | null> {
  const supabase = createAdminClient()
  
  // Tenta gerar key única (máximo 5 tentativas)
  for (let i = 0; i < 5; i++) {
    const key = generateKey()
    
    // Importa PLANOS aqui para evitar circular dependency
    const { PLANOS } = await import('./types')
    const expiraEm = calcularExpiracao(plano, PLANOS)
    
    const { data, error } = await supabase
      .from('keys')
      .insert({
        key,
        plano,
        preco_centavos: precoCentavos,
        expira_em: expiraEm?.toISOString() || null,
        payment_id: paymentId,
        payment_status: 'pending',
        email_comprador: email || null
      })
      .select()
      .single()
    
    if (!error && data) {
      return data as Key
    }
    
    // Se erro não for de duplicação, falha
    if (error && !error.message.includes('duplicate')) {
      console.error('Erro ao criar key:', error)
      return null
    }
  }
  
  return null
}

// Busca key por texto
export async function buscarKey(keyText: string): Promise<Key | null> {
  const supabase = createAdminClient()
  
  const { data, error } = await supabase
    .from('keys')
    .select('*')
    .eq('key', keyText.toUpperCase())
    .single()
  
  if (error || !data) return null
  return data as Key
}

// Busca key por payment_id
export async function buscarKeyPorPayment(paymentId: string): Promise<Key | null> {
  const supabase = createAdminClient()
  
  const { data, error } = await supabase
    .from('keys')
    .select('*')
    .eq('payment_id', paymentId)
    .single()
  
  if (error || !data) return null
  return data as Key
}

// Atualiza status do pagamento da key
export async function atualizarStatusPagamento(
  keyId: string,
  status: 'pending' | 'approved' | 'rejected' | 'cancelled'
): Promise<boolean> {
  const supabase = createAdminClient()
  
  const { error } = await supabase
    .from('keys')
    .update({ payment_status: status })
    .eq('id', keyId)
  
  return !error
}

// Vincula device à key
export async function vincularDevice(
  keyId: string,
  deviceId: string,
  ip: string
): Promise<boolean> {
  const supabase = createAdminClient()
  
  const { error } = await supabase
    .from('keys')
    .update({
      device_id: deviceId,
      ip,
      last_use: new Date().toISOString()
    })
    .eq('id', keyId)
  
  return !error
}

// Atualiza último uso
export async function atualizarUltimoUso(keyId: string, ip: string): Promise<boolean> {
  const supabase = createAdminClient()
  
  const { error } = await supabase
    .from('keys')
    .update({
      last_use: new Date().toISOString(),
      ip
    })
    .eq('id', keyId)
  
  return !error
}

// Incrementa tentativas bloqueadas
export async function incrementarTentativasBloqueadas(keyId: string): Promise<number> {
  const supabase = createAdminClient()
  
  // Primeiro busca o valor atual
  const { data: keyData } = await supabase
    .from('keys')
    .select('tentativas_bloqueadas')
    .eq('id', keyId)
    .single()
  
  const novoValor = (keyData?.tentativas_bloqueadas || 0) + 1
  
  // Atualiza
  await supabase
    .from('keys')
    .update({ tentativas_bloqueadas: novoValor })
    .eq('id', keyId)
  
  return novoValor
}

// Suspende key
export async function suspenderKey(keyId: string, motivo: string): Promise<boolean> {
  const supabase = createAdminClient()
  
  const { error } = await supabase
    .from('keys')
    .update({
      suspensa: true,
      ativa: false,
      motivo_suspensao: motivo
    })
    .eq('id', keyId)
  
  return !error
}

// Verifica se key está expirada
export function keyExpirada(key: Key): boolean {
  if (!key.expira_em) return false // Lifetime nunca expira
  return new Date(key.expira_em) < new Date()
}

// Verifica variação de IP (permite mudanças em mobile)
export function ipSuspeito(ipOriginal: string | null, ipAtual: string): boolean {
  if (!ipOriginal) return false
  
  // Extrai os primeiros 2 octetos para comparação
  const original = ipOriginal.split('.').slice(0, 2).join('.')
  const atual = ipAtual.split('.').slice(0, 2).join('.')
  
  // Se mudou completamente os 2 primeiros octetos, é suspeito
  return original !== atual
}
